<section class="navBar-section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="nav-bar d-flex">
                    <img class="menu" id="toggle" class="img-fluid" src="images/menu.png" alt="menu">
                    <div class="logoWrapper" >
                        <a href="index.php"><img src="images/logo.svg" alt="FaizalCP"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>